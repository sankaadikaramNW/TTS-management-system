from datetime import datetime, date
from sqlalchemy import Column, String, Integer, Double, Date, DateTime, ForeignKey, Text, Boolean, UniqueConstraint, Index
from sqlalchemy.orm import relationship
from app.database import Base
from app.models.base import generate_uuid, TimeStampedModelMixin

class Classroom(Base, TimeStampedModelMixin):
    __tablename__ = 'classrooms'

    id = Column(String(36), primary_key=True, default=generate_uuid)
    code = Column(String(50), unique=True, nullable=False) # e.g. E-01, H-05
    name = Column(String(150), nullable=False) # e.g. Electronics Lab 01
    block = Column(String(100), nullable=True) # e.g. Engineering Block
    building = Column(String(100), nullable=True)
    capacity = Column(Integer, default=30, nullable=False)
    description = Column(Text, nullable=True)
    is_active = Column(Boolean, default=True)

    # Relationships
    batches = relationship("Batch", back_populates="classroom")

class Course(Base, TimeStampedModelMixin):
    __tablename__ = 'courses'

    id = Column(String(36), primary_key=True, default=generate_uuid)
    code = Column(String(30), unique=True, nullable=False)
    name = Column(String(150), nullable=False)
    trade_id = Column(String(36), ForeignKey('trades.id', ondelete='SET NULL'), nullable=True)
    course_type = Column(String(50), default='Basic') # Basic, Advance, Special
    duration_weeks = Column(Integer, nullable=False, default=24)
    intake_capacity = Column(Integer, default=30)
    start_date = Column(Date, nullable=True)
    end_date = Column(Date, nullable=True)
    description = Column(Text, nullable=True)
    status = Column(String(30), default='ONGOING', index=True) # UPCOMING, ONGOING, PASSED OUT
    is_active = Column(Boolean, default=True)

    __table_args__ = (
        Index('idx_courses_status_end_date', 'status', 'end_date'),
        Index('idx_courses_is_active_end_date', 'is_active', 'end_date'),
        Index('idx_courses_trade_status', 'trade_id', 'status'),
    )

    # Relationships
    trade = relationship("Trade")
    batches = relationship("Batch", back_populates="course", cascade="all, delete-orphan")
    students = relationship("Student", back_populates="course")
    subjects = relationship("Subject", back_populates="course", cascade="all, delete-orphan")
    timetables = relationship("Timetable", back_populates="course", cascade="all, delete-orphan")
    exams = relationship("Exam", back_populates="course", cascade="all, delete-orphan")
    lesson_plan_documents = relationship("LessonPlanDocument", back_populates="course", cascade="all, delete-orphan")
    calendar_entries = relationship("CourseCalendar", back_populates="course", cascade="all, delete-orphan")

class Batch(Base, TimeStampedModelMixin):
    __tablename__ = 'batches'

    id = Column(String(36), primary_key=True, default=generate_uuid)
    name = Column(String(100), nullable=False) # e.g. Batch 2026-A
    course_id = Column(String(36), ForeignKey('courses.id', ondelete='CASCADE'), nullable=False)
    trade_id = Column(String(36), ForeignKey('trades.id', ondelete='SET NULL'), nullable=True)
    intake_date = Column(Date, nullable=True)
    passing_out_date = Column(Date, nullable=True)
    capacity = Column(Integer, default=30)
    classroom_id = Column(String(36), ForeignKey('classrooms.id', ondelete='SET NULL'), nullable=True)
    instructor_id = Column(String(36), ForeignKey('users.id', ondelete='SET NULL'), nullable=True)
    status = Column(String(30), default='Active', index=True) # Active, Completed, Archived, PASSED OUT

    __table_args__ = (
        Index('idx_batches_status_passing_out_date', 'status', 'passing_out_date'),
        Index('idx_batches_course_status', 'course_id', 'status'),
        Index('idx_batches_classroom_status', 'classroom_id', 'status'),
        Index('idx_batches_instructor_status', 'instructor_id', 'status'),
    )

    # Relationships
    course = relationship("Course", back_populates="batches")
    trade = relationship("Trade")
    classroom = relationship("Classroom", back_populates="batches")
    instructor = relationship("User")

class Subject(Base, TimeStampedModelMixin):
    __tablename__ = 'subjects'

    id = Column(String(36), primary_key=True, default=generate_uuid)
    course_id = Column(String(36), ForeignKey('courses.id', ondelete='CASCADE'), nullable=False, index=True)
    code = Column(String(30), nullable=False)
    name = Column(String(150), nullable=False)
    description = Column(Text, nullable=True)
    periods = Column(Integer, default=40, nullable=False)

    # Relationships
    course = relationship("Course", back_populates="subjects")
    lessons = relationship("Lesson", back_populates="subject", cascade="all, delete-orphan")
    timetables = relationship("Timetable", back_populates="subject", cascade="all, delete-orphan")
    exams = relationship("Exam", back_populates="subject", cascade="all, delete-orphan")

class Lesson(Base):
    __tablename__ = 'lessons'

    id = Column(String(36), primary_key=True, default=generate_uuid)
    subject_id = Column(String(36), ForeignKey('subjects.id', ondelete='CASCADE'), nullable=False)
    name = Column(String(150), nullable=False)
    description = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    subject = relationship("Subject", back_populates="lessons")
    lesson_plans = relationship("LessonPlan", back_populates="lesson", cascade="all, delete-orphan")
    timetables = relationship("Timetable", back_populates="lesson")

class LessonPlan(Base):
    __tablename__ = 'lesson_plans'

    id = Column(String(36), primary_key=True, default=generate_uuid)
    lesson_id = Column(String(36), ForeignKey('lessons.id', ondelete='CASCADE'), nullable=False)
    instructor_id = Column(String(36), ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    duration_minutes = Column(Integer, default=45)
    objectives = Column(Text, nullable=True)
    training_aids = Column(Text, nullable=True)
    references_used = Column(Text, nullable=True)
    plan_doc_path = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    lesson = relationship("Lesson", back_populates="lesson_plans")
    instructor = relationship("User")

class Timetable(Base):
    __tablename__ = 'timetables'

    id = Column(String(36), primary_key=True, default=generate_uuid)
    course_id = Column(String(36), ForeignKey('courses.id', ondelete='CASCADE'), nullable=False)
    date = Column(Date, nullable=False)
    period_number = Column(Integer, nullable=False)  # 1, 2, 3, 4, 5, 6, 7, 8
    subject_id = Column(String(36), ForeignKey('subjects.id', ondelete='CASCADE'), nullable=False)
    lesson_id = Column(String(36), ForeignKey('lessons.id', ondelete='CASCADE'), nullable=False)
    instructor_id = Column(String(36), ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    location = Column(String(100), default='Main Lecture Hall')
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    course = relationship("Course", back_populates="timetables")
    subject = relationship("Subject", back_populates="timetables")
    lesson = relationship("Lesson", back_populates="timetables")
    instructor = relationship("User")
    attendance = relationship("AcademicAttendance", back_populates="timetable", cascade="all, delete-orphan")

class AcademicAttendance(Base):
    __tablename__ = 'academic_attendance'
    __table_args__ = (
        UniqueConstraint('timetable_id', 'student_id', name='uq_timetable_student'),
    )

    id = Column(String(36), primary_key=True, default=generate_uuid)
    timetable_id = Column(String(36), ForeignKey('timetables.id', ondelete='CASCADE'), nullable=False)
    student_id = Column(String(36), ForeignKey('students.id', ondelete='CASCADE'), nullable=False)
    status = Column(String(30), default='PRESENT')  # PRESENT, ABSENT, LATE, SICK_REPORT, COURSE_VISIT, LEAVE, HOSPITAL, EXCUSED
    remarks = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    timetable = relationship("Timetable", back_populates="attendance")
    student = relationship("Student", back_populates="attendance")

class Exam(Base, TimeStampedModelMixin):
    __tablename__ = 'exams'

    id = Column(String(36), primary_key=True, default=generate_uuid)
    course_id = Column(String(36), ForeignKey('courses.id', ondelete='CASCADE'), nullable=False)
    subject_id = Column(String(36), ForeignKey('subjects.id', ondelete='CASCADE'), nullable=False)
    type = Column(String(30), nullable=False)  # Phase Test, Final Exam
    date = Column(Date, nullable=False)
    max_marks = Column(Double, default=100.0)
    pass_marks = Column(Double, default=50.0)

    # Relationships
    course = relationship("Course", back_populates="exams")
    subject = relationship("Subject", back_populates="exams")
    marks = relationship("ExamMark", back_populates="exam", cascade="all, delete-orphan")

class ExamMark(Base):
    __tablename__ = 'exam_marks'

    id = Column(String(36), primary_key=True, default=generate_uuid)
    exam_id = Column(String(36), ForeignKey('exams.id', ondelete='CASCADE'), nullable=False)
    student_id = Column(String(36), ForeignKey('students.id', ondelete='CASCADE'), nullable=False)
    marks_obtained = Column(Double, nullable=False)
    status = Column(String(20), nullable=False)  # Pass, Fail, Absent, or LEAVE, HOSPITAL, AWOL, COURSE_VISIT
    remarks = Column(Text, nullable=True)
    entered_by = Column(String(36), ForeignKey('users.id', ondelete='SET NULL'), nullable=True)
    is_overridden = Column(Boolean, default=False)
    override_reason = Column(Text, nullable=True)
    overridden_by = Column(String(36), ForeignKey('users.id', ondelete='SET NULL'), nullable=True)
    overridden_at = Column(DateTime, nullable=True)
    original_parade_status = Column(String(50), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    exam = relationship("Exam", back_populates="marks")
    student = relationship("Student", back_populates="exam_marks")
    recorder = relationship("User", foreign_keys=[entered_by])
    overriding_user = relationship("User", foreign_keys=[overridden_by])

class LessonPlanDocument(Base):
    __tablename__ = 'lesson_plan_documents'

    id = Column(String(36), primary_key=True, default=generate_uuid)
    course_id = Column(String(36), ForeignKey('courses.id', ondelete='CASCADE'), nullable=False, index=True)
    lesson_id = Column(String(36), ForeignKey('lessons.id', ondelete='SET NULL'), nullable=True)
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    subject_name = Column(String(150), nullable=True)
    version = Column(String(20), nullable=True)
    academic_year = Column(String(20), nullable=True)
    remarks = Column(Text, nullable=True)
    original_file_name = Column(String(255), nullable=False)
    cloudinary_public_id = Column(String(255), nullable=False)
    cloudinary_url = Column(String(500), nullable=False)
    resource_type = Column(String(30), default='raw')
    file_size = Column(Integer, nullable=False)
    mime_type = Column(String(50), default='application/pdf')
    uploaded_by = Column(String(36), ForeignKey('users.id', ondelete='SET NULL'), nullable=True, index=True)
    status = Column(String(20), default='Active', index=True)  # Active, Archived
    uploaded_at = Column(DateTime, default=datetime.utcnow, index=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    course = relationship("Course", back_populates="lesson_plan_documents")
    lesson = relationship("Lesson")
    uploader = relationship("User")

class CourseCalendar(Base):
    __tablename__ = 'course_calendar'

    id = Column(String(36), primary_key=True, default=generate_uuid)
    course_id = Column(String(36), ForeignKey('courses.id', ondelete='CASCADE'), nullable=False, index=True)
    subject_id = Column(String(36), ForeignKey('subjects.id', ondelete='SET NULL'), nullable=True, index=True)
    serial_number = Column(Integer, nullable=False)
    phase_name = Column(String(255), nullable=False)
    theory_periods = Column(Integer, default=0, nullable=False)
    practical_periods = Column(Integer, default=0, nullable=False)
    total_periods = Column(Integer, default=0, nullable=False)
    working_days = Column(Integer, default=0, nullable=False)
    commencement_date = Column(Date, nullable=False, index=True)
    completion_date = Column(Date, nullable=False, index=True)
    instructor_id = Column(String(36), ForeignKey('users.id', ondelete='SET NULL'), nullable=True, index=True)
    instructor_status = Column(String(30), default='NOT_ASSIGNED', nullable=False, index=True)
    remarks = Column(Text, nullable=True)
    status = Column(String(30), default='Active', index=True)
    created_by = Column(String(36), ForeignKey('users.id', ondelete='SET NULL'), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    course = relationship("Course", back_populates="calendar_entries")
    subject = relationship("Subject", foreign_keys=[subject_id])
    instructor = relationship("User", foreign_keys=[instructor_id])
    creator = relationship("User", foreign_keys=[created_by])
