import io
import base64
import qrcode
from datetime import date
from typing import Optional
from fastapi import HTTPException
from sqlalchemy.orm import Session
from app.models.student import Student
from app.repositories.student import student_repo
from app.repositories.user import audit_repo
from app.schemas.student import StudentCreate, StudentUpdate

class StudentService:
    def create_student(self, db: Session, student_in: StudentCreate, user_id: str, ip: str, ua: str) -> Student:
        # Check duplicate service number
        if student_repo.get_by_service_number(db, student_in.service_number):
            raise HTTPException(status_code=400, detail=f"Student with Service Number '{student_in.service_number}' already exists")
            
        # Check duplicate NIC (only if NIC is provided and non-empty)
        if student_in.nic and student_in.nic.strip():
            if student_repo.get_by_nic(db, student_in.nic.strip()):
                raise HTTPException(status_code=400, detail=f"Student with NIC '{student_in.nic}' already exists")

        # Validate Course and Batch if course_id is provided
        from app.models.academic import Course, Batch
        batch_value = student_in.batch
        if student_in.course_id:
            course = db.query(Course).filter(Course.id == student_in.course_id, Course.deleted_at == None).first()
            if not course:
                raise HTTPException(status_code=400, detail="Selected course does not exist in Academic Activity master records.")
            if not course.is_active:
                raise HTTPException(status_code=400, detail="Selected course is inactive and unavailable for trainee enrollment.")
            if not batch_value or not batch_value.strip():
                active_batch = db.query(Batch).filter(Batch.course_id == course.id, Batch.status == 'Active').first()
                batch_value = active_batch.name if active_batch else course.code

        # Generate QR code representation
        qr_base64 = self.generate_student_qr(student_in.service_number)

        db_student = Student(
            service_number=student_in.service_number,
            initials=student_in.initials or "",
            full_name=student_in.full_name,
            nic=student_in.nic.strip() if (student_in.nic and student_in.nic.strip()) else None,
            dob=student_in.dob or date(2000, 1, 1),
            gender=student_in.gender or "Male",
            rank=student_in.rank or "AC",
            trade=student_in.trade or "Airframe",
            course_id=student_in.course_id,
            batch=batch_value or "Intake 171",
            joining_date=student_in.joining_date or date.today(),
            passing_out_date=student_in.passing_out_date,
            status=student_in.status or "Active",
            phone=student_in.phone,
            email=student_in.email.strip() if (student_in.email and student_in.email.strip()) else None,
            emergency_contact_name=student_in.emergency_contact_name or "N/A",
            emergency_contact_phone=student_in.emergency_contact_phone or "N/A",
            blood_group=student_in.blood_group or "O+",
            medical_category=student_in.medical_category or "A4G4",
            religion=student_in.religion or "Buddhist",
            nationality=student_in.nationality or "Sri Lankan",
            permanent_address=student_in.permanent_address or "N/A",
            temporary_address=student_in.temporary_address,
            qr_code_data=qr_base64
        )

        student = student_repo.create(db, obj_in=db_student)
        
        # Record initial parade state for registration date
        from app.repositories.parade import parade_repo
        parade_repo.create_or_update(
            db,
            student_id=student.id,
            parade_date=student.joining_date,
            status=student.status or "Present",
            remarks="Initial registration record",
            user_id=user_id
        )

        audit_repo.create_log(
            db, user_id, "STUDENT_CREATED", ip, ua, 
            f"Created student record {student.service_number} ({student.full_name})"
        )
        return student

    def update_student(self, db: Session, student_id: str, student_in: StudentUpdate, user_id: str, ip: str, ua: str) -> Student:
        student = student_repo.get(db, student_id)
        if not student or student.deleted_at:
            raise HTTPException(status_code=404, detail="Student record not found")

        # NIC duplicate check
        if student_in.nic and student_in.nic != student.nic:
            if student_repo.get_by_nic(db, student_in.nic):
                raise HTTPException(status_code=400, detail=f"Another student with NIC '{student_in.nic}' already exists")

        # Course validation on update
        if student_in.course_id is not None and student_in.course_id != "":
            from app.models.academic import Course
            course = db.query(Course).filter(Course.id == student_in.course_id, Course.deleted_at == None).first()
            if not course:
                raise HTTPException(status_code=400, detail="Selected course does not exist in Academic Activity master records.")
            if not course.is_active:
                raise HTTPException(status_code=400, detail="Selected course is inactive and unavailable for trainee enrollment.")

        # Status changes trigger audits
        status_change = ""
        if student_in.status and student_in.status != student.status:
            status_change = f"Status changed from {student.status} to {student_in.status}"
            student.status = student_in.status

        updated_student = student_repo.update(db, db_obj=student, obj_in=student_in)
        audit_repo.create_log(
            db, user_id, "STUDENT_UPDATED", ip, ua, 
            f"Updated student record {updated_student.service_number}. {status_change}"
        )
        return updated_student

    def delete_student(self, db: Session, student_id: str, user_id: str, ip: str, ua: str) -> Student:
        student = student_repo.get(db, student_id)
        if not student or student.deleted_at:
            raise HTTPException(status_code=404, detail="Student record not found")

        deleted_student = student_repo.remove(db, id=student_id)
        audit_repo.create_log(
            db, user_id, "STUDENT_DELETED", ip, ua, 
            f"Soft-deleted student record {student.service_number} ({student.full_name})"
        )
        return deleted_student

    def generate_student_qr(self, service_number: str) -> str:
        # Generate base64 data URL representing QR code
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        # Validation payload contains Service Number
        qr.add_data(f"SLAF_TTS_VALIDATION:{service_number}")
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        
        buffered = io.BytesIO()
        img.save(buffered)
        img_str = base64.b64encode(buffered.getvalue()).decode("utf-8")
        return f"data:image/png;base64,{img_str}"

student_service = StudentService()
